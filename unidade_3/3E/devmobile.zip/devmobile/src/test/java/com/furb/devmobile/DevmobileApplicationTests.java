package com.furb.devmobile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevmobileApplicationTests {

	@Test
	void contextLoads() {
	}

}
